# Square Auctions Render
Este es un placeholder del proyecto porque el archivo original se perdió al reiniciarse el entorno.
